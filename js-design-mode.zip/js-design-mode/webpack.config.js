const path= require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports = {
	mode:'development',
	entry:'./src/index.js',
	output:{
		path:__dirname,
		filename:'./release/bundle.js'
	},
	plugins:[
		new HtmlWebpackPlugin({
			template:'./index.html'
		})
	],
	devServer:{
		contentBase:path.join(__dirname,'./release'),
		open:true,//自动打开浏览器
		port:9000,
		proxy:{
			'/api/*':{
				target:'http://localhost:8880'
			}
		}
	},
	module:{
		rules:[
			{
				test:/\.js?$/,
				exclude:/node_modules/,
				use:{
					loader:'babel-loader',
					options:{
						presets:["babel-preset-es2015","babel-preset-latest"],
						plugins:[]
					}
				}
			}
		]
	}
}
