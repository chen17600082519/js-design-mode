import getCart from './GetCart.js';
import $ from 'jquery';


export default class ShoppingCart {
	constructor(app){
		this.app = app;
		this.$el = $('<div>').css({
			'padding-bottom':'10px',
			'border-bottom':'1px solid #ddd',
			'position':'fixed',
			'right':'0',
			'bottom':'0'
		})
		this.cart = getCart();
	}
	initBtn(){
		let $btn = $('<button>购物车</button>');
		$btn.click(()=>{
			this.showCart();
		});
		this.app.$el.append($btn);
	}
	showCart(){
		alert(this.cart.getList());
	}
	init(){
		this.initBtn();
	}
}
