export const GET_LIST = '/api/list.json';
