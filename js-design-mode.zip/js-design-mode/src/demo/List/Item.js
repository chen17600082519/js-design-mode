import $ from 'jquery';
import getCart from '../ShoppingCart/GetCart.js';

export default class Item{
	constructor(list,data){
		this.list = list;
		this.data = data;
		this.$el = $('<div>');
		this.cart = getCart();
		this.isShouCang = false;
	}
	initContent(){
		let $el = this.$el;
		let data = this.data;
		$el.append($(`<p>名称:${data.name}</p>`));
		$el.append($(`<p>价格:${data.price}</p>`));
	}
	initBtn(){
		let $el = this.$el;
		let _this=this;
		let $btn = $('<button></button>');
		if(!this.isShouCang){
			$btn.html('添加到购物车')
		}else{
			$btn.html('从购物车中删除')
		}
		$btn.click(()=>{
			//添加到购物车
			if(!_this.isShouCang){
				_this.addToCart();
				_this.isShouCang=true;
				$btn.html('从购物车中删除')
			}else{
				_this.deleteFromCart();
				_this.isShouCang=false;
				$btn.html('添加到购物车')
			}
			//从购物车中删除
		});
		$el.append($btn);
	}
	addToCart(){
		this.cart.add(this.data);
	}
	deleteFromCart(){                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
		this.cart.del(this.data.id);
	}
	render(){
		this.list.$el.append(this.$el);
	}
	init(){
		this.initContent();
		this.initBtn();
		this.render();
	}
}
