//工厂模式，封装new操作，原则：构造函数和创建者分离，符合开放封闭原则
class Product{
	constructor(name){
		this.name=name;
	}
	init(){
		alert('init');
	}
	fn1(){
		alert('fn1');
	}
	fn2(){
		alert('fn2');
	}
}

class Creator{
	create(name){
		return new Product(name);
	}
}
let creator=new Creator();
let p1=creator.create('p1');
let p2=creator.create('p2');
console.log(p1.name);
p1.fn1(); 
console.log(p2.name);
p2.init();
