//系统中被唯一使用，一个类只有一个实例
//符合单一职责原则，只实例化唯一的对象
//没法具体体现开放封闭原则，但是绝对不违反开放封闭原则
class SingleObject {
	login(a){
		console.log(a);
	}
}

SingleObject.getInstance = (()=>{
	let instance;
	return ()=>{
		if(!instance){
			instance = new SingleObject()			
		}
		
		return instance;
	}
})()

let obj1=SingleObject.getInstance();
obj1.login(1);
let obj2=SingleObject.getInstance();
obj2.login(2);
console.log('obj1===obj2',obj1===obj2);


let obj3 = new SingleObject();  //无法完全控制
obj3.login(1);
console.log('obj1===obj3',obj1===obj3)





