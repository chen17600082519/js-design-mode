//代理模式，使用者无权访问目标对象，中间加代理，通过代理做授权和控制
class RealImg {
	constructor(fileName){
		this.fileName =fileName;
		this.loadFormDisk();
	}
	display(){
		console.log('display...'+this.fileName)
	}
	loadFormDisk(){
		console.log('loading...'+this.fileName)
	}
}
class ProxyImg{
	constructor(fileName){
		this.realImg =new RealImg(fileName);
	}
	display(){
		this.realImg.display();
	}
}


//测试
let proxyImg= new ProxyImg('1.png');

proxyImg.display();
