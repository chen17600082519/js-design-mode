function each(data){
	for(let item of data){
		console.log(item);
	}
}

let arr = [1,2,3,4];
let nodeList = document.getElementsByTagName('p');
let m =new Map();
m.set('a',100);
m.set('b',200);
each(m);
each(nodeList);
