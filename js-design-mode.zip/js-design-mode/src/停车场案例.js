//车类
class Car{
	constructor(num){
		this.num=num
	}
}
//相机
class Camera {
	shot(car){
		return {
			num:car.num,
			inTime:Date.now()
		}
	}
}
//屏幕
class Screen {
	show(car,inTime){
		console.log('车牌号',car.num);
		console.log('停车时间',Date.now()-inTime);
	}
}
//停车场
class Park{
	constructor(floors){
		this.floors=floors || [];
		this.camera=new Camera();
		this.screen=new Screen();
		this.carList={};
	}
	in(car){
		let info=this.camera.shot(car);
		let i=parseInt(Math.random()*20);
		let f=parseInt(Math.random()*3);
		if(this.floors[f].places[i].empty){
			const place=this.floors[f].places[i];
			place.in();
			info.place=place;
			this.carList[car.num]=info;
		}else{
			console.log('停重了');
			this.in(car);
		};
		
	}
	out(car){
		const info = this.carList[car.num];
		const place=info.place;
		place.out();
		this.screen.show(car,info.inTime);
		delete this.carList[car.num];
	}
	emptyNum(){
		return this.floors.map(floor=>{
			return `${floor.index}层还有${floor.emptyPlaceNum()}个空位`;
		}).join('\n');
	}
}
//层
class Floor{
	constructor(index,places){
		this.index=index;
		this.places=places;
	}
	emptyPlaceNum(){
		let num=0;
		this.places.forEach(p=>{
			if(p.empty){
				num++;
			}
		})
		return num;
	}
}
//停车位
class Place {
	constructor(floorIndex,placeIndex){
		this.empty=true;
		this.floorIndex=floorIndex;
		this.placeIndex=placeIndex;
	}
	in(){
		this.empty=false;
	}
	out(){
		this.empty=true;
	}
}


//测试
//初始化停车场
const floors=[]
for (let i=0;i<3;i++){
	const places =[]
	for(let j=0;j<20;j++){
		places[j]=new Place(i,j);
	}
	floors[i]=new Floor(i+1,places);
}
const park=new Park(floors);


//初始化车辆
const car1=new Car(101);
const car2=new Car(102);
const car3=new Car(103);
const car4=new Car(104);
const car5=new Car(105);
const car6=new Car(106);
console.log(park.emptyNum());
console.log('先后进入六辆车');
park.in(car1);
park.in(car2);
park.in(car3);
park.in(car4);
park.in(car5);
park.in(car6);
for(let i in park.carList){
	console.log(i,park.carList[i].place);
}
console.log(park.emptyNum());

console.log('第二辆车离开');
park.out(car2);
for(let i in park.carList){
	console.log(i,park.carList[i].place);
}
console.log(park.emptyNum());
console.log('第一辆车离开');
park.out(car1);
for(let i in park.carList){
	console.log(i,park.carList[i].place);
}
console.log(park.emptyNum());
